require "ants"

describe Map do
  it "should not clear our ants unless we see they die" do
  end
end
